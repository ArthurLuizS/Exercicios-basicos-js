function contar(){
    var inic = window.document.getElementById('txtinic')
    var fim = window.document.getElementById('txtfim')
    var passo = window.document.getElementById('txtpasso')
    var res = window.document.getElementById('res')
    
    
    if(inic.value.lenght == 0 || fim.value.lenght ==0 || passo.value.lenght==0){
       window.alert('ERRO')
    } else {
        
        res.innerHTML=('Contando...')
        var i = Number(inic.value)
        var f = Number(fim.value)
        var p = Number(passo.value)
        for (let c = i; c<f; c+=p){
            res.innerHTML+=`${c}`
        } 

    }
   
    }
   
        
    
